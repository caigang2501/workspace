




def main(lst):
    return lst

